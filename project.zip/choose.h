#include <stdio.h>
#include "ship.h"
#include "play.h"




int printing(){
    int n;
    printf("welcome to us\n\n");
    printf("1- Play with friends\n2- Play with bot\n3- Load game\n4- Load lastgame\n5-Settings\n6-Score board\n7-Exit\n");
    printf("enter : ");
    scanf("%d",&n);
    return n;
}

void choose(int n){
   // char name[20][20];
    int z , i;
    head_1 = NULL;
    head_2 = NULL;
 //   nod *head[]
    if(n == 1){
        for(i = 0 ; i < 2 ; i++){
        printf("1-choose from available users\n2-new user\nenter : ");
        scanf("%d",&z);
        if(z == 1){
            available(name[i]);
        }
        if(z == 2){
            sign_up(name[i]);
        }
     //   printf("%s\n",name[i]);
     //   puts(name[i]);
        maps();
        if(i == 0)
            build(name[i],i);
        else
            build(name[i],i);
    //    show(head_1,len);
        }
        play();
    }
    else if(n == 2){
        printf("1-choose from available users\n2-new user\nenter : ");
        scanf("%d",&z);
        if(z == 1)
            available(name[0]);
        if(z == 2)
            sign_up(name[0]);
        maps();
        build(name[0],0);
        bot();
    }
}

void sign_up( char name[20]){
    int num;
    FILE *fl = fopen("name.txt","a+");
    printf("ENTER YOUR USESR NAME: \n");
    scanf("%s",name);
    fprintf(fl , "%s 0\n" , name);
    fclose(fl);
    FILE *fd = fopen("name.txt","r+");
    fscanf(fl , "%d" , &num);
    num++;
    fseek(fl , 0 , SEEK_SET);
  //  ftell(fl);
    fprintf(fl , "%d" , num);
     fclose(fd);
}

void available(char name[20]){
    int i = 0 , num ,a;
    char N[20][20];
    FILE * fl = fopen("name.txt","r+");
    fscanf(fl , "%d" , &num);
    while(i < num ){
        fscanf(fl , "%s" , N[i]);
        fseek(fl,sizeof(int),SEEK_CUR);
        printf("%d- %s\n" ,i+1 , N[i]);
        i++;
    }
    scanf("%d",&a);
    name = N[a-1] ;
 //   printf("%s\n" ,N[a-1]);
    system("cls");
    printf("%s\n" ,name);
    fclose(fl);
  //  printf("%s\n" ,name);
}
