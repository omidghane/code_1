#include <stdio.h>

void map_game(int b,int c,int s){
    system("cls");
    int q=1,i,j,m = 0,n = 0,z , k;
    int x[10] = {-1}, y[10] = {-1};
    printf("   1 2 3 4 5 6 7 8 9 10\n");
    for(i=0;i<10;i++){
        if(i == 9)
            printf("%d ",q++);
        else
            printf("%d  ",q++);
        for(j=0;j<10;j++){
            if(b == i && c==j){
                if(s == 1){
                    if(j == 9)
                        printf("0\n");
                    else
                        printf("0 ");
                }
                if(s == 2){
                    if(j == 9)
                        printf("+\n");
                    else
                        printf("+ ");
                }
                if(s == 3){
                    if(j == 9)
                        printf("*\n");
                    else
                        printf("* ");
                }
                x[m] = i;
                y[n] = j;
                m++;
                n++;
            }
            else{
                for(z=0;z<10;z++){
                    for(k=0;k<10;k++){
                    if(x[z]==i && y[k]==j)
                        goto lb;
                    }
                }
                lb:
                 if(j == 9)
                        printf(".\n");
                else
                        printf(". ");
                }
        }
        }

}

char name[20][20];

void play(){
    int i , j ,s , k=0 , v=0 ,b[100] = {0} , c[100] = {0};
 //   b[100] = 0;
    map_game(-1,-1,0);
    while(head_1 == NULL ||head_2 == NULL){
    scanf("%d%d",&i,&j);
   k = load(a[i][j],b,k);
    s = check_ship(name[0],a[i][j],head_1,k);
    if(s == 0)
        continue;
    map_game(i-1,j-1,s);
    la:
    scanf("%d%d",&i,&j);
    v = load(a[i][j],c);
    s = check_ship(name[1],a[i][j],head_2,v);
    if(s == 0)
        goto la;
     map_game(i-1,j-1,s);
    }
}

int load(int q,int b[100],int k){
    int i;
    for(i=0;i<100;i++){
        if( b[i] == q){
            return k;
        }
    }
    b[k] = q;
    k++;
    return k;
}

int check_ship(char name[20],int q,nod *head,int b[100]){
    nod *temp = head;
    int i,j,z , result, num=0;
    for(i=0;i<100;i++){
        if( b[i] == q){
            printf("invalid point");
            return 0;
        }
    }
    while(temp != NULL){
        for(z=0;z<5;z++){
            if((temp->inf[z]) == q ){
                    while(temp->inf[num] != 0)
                        num++;
                    for(i=0;i<num;i++){
                        if((temp->inf[i]) != q ){
                            return 2;
                        }
                    }
         //   delete_nod();
            return 3;
            }
        }
        temp = temp->next;
    }
    return 1;
}




/*void gotoxy(int x, int y){
HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
COORD cursorCoord;
cursorCoord.X=x;
cursorCoord.Y=y;
SetConsoleCursorPosition(consoleHandle, cursorCoord);
}*/
