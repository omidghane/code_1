#include <stdio.h>
#include "bot.h"



nod *creat_nod(int val[5],int len){
    int i;
    nod *temp = (nod*)malloc(sizeof(nod));
    if(temp == NULL)
        return;
    for(i=0;i<5;i++)
        temp->inf[i] = 0;
    for(i=0;i<len;i++){
        temp->inf[i] = val[i];
  //      printf("%d\n",temp->inf[i]);
    }
    temp->next = NULL;
    return temp;

    }


void addend(nod **head ,int val[5] ,int len){
    nod *x ;
    int i;
    nod *newnod = creat_nod(val,len);
    if(*head == NULL){
        *head = newnod;
    }
    else{
        x = *head;
        while(x->next != NULL){
            x = x->next;
        }
        x->next = newnod;
    //    x = newnod;
 //   for(i=0;i<len;i++)
 //      printf("m : %d\n",x->inf[i]);
    }
}

void show(nod *head,int len[20]){
    int i , j=0;
    nod *temp = head;
    while(temp != NULL){
        for(i=0;i<len[j];i++){
            printf("%d :",len[j]);
            printf(" %d\n",temp->inf[i]);
        }
        j++;
        temp = temp->next;
    }

}

int  b[100];

void maps(){
  //   printf("%s\n",name);
    int i , j;
   // nod *head = NULL;
    for(i=0;i<10;i++){
        for(j=0;j<10;j++){
            a[i][j] = (i*10) + (j+1);
        }
    }
     for(i=0;i<10;i++){
        for(j=0;j<10;j++){
            if(a[i][j]>0 && a[i][j]<10)
                 printf(" 0%d",a[i][j]);
            else
                printf(" %d",a[i][j]);
            if(j==9)
                printf("\n");
        }
     }
}

void build(char name[20],int rim){
   // nod *temp = *head;
    head_1 = NULL;
    head_2 = NULL;
    int i , j=0 , len[20] ,p[20] ,help ;
    for(i=0;i<3;i++){
        printf("enter the lengh of chosen ship : ");
        scanf("%d",&len[i]);
        printf("put your ship : ");
        if(len[i] == 1){
             fflush(stdin);
            scanf("%d",&p[0]);
            serching(p,len[i],rim);
        }
        else if(len[i] > 1 && len[i] < 6){
            for(j=0;j<2;j++){
               p[j] = 0;
          //      fflush(stdin);
            }
            for(j=0;j<2;j++){
                scanf("%d",&p[j]);
          //      fflush(stdin);
            }
            if(p[1] < p[0]){
                help = p[0];
                p[0] = p[1];
                p[1] = help;
            }
            serching(p,len[i],rim);
        }
     //   show(head_1,len);
      //   printf("%d",(head_1)->inf[0]);
    }
   // printf("ok : %d\n",rim);
    if(rim == 0)
        show(head_1,len);
    if(rim == 1)
        show(head_2,len);
 //   printf("%d\n",(head_1)->inf[0]);
}

void serching(int p[20],int len,int rim){
    int i , j , z=0 ,  n=0 , b[100] , t;
    b[100]= 0;
    nod *temp;
//    printf("%d\n",rim);
   /* if(rim == 0)
        temp = head_1;
    else if(rim == 1)
        temp = head_2;*/
    for(i=0;i<10;i++){
        for(j=0;j<10;j++){
            if(a[i][j] == p[0] ){
                if(len==1){
                }
                else if((p[1]-p[0]) < 5){
                    for(z=0;z<len;z++){
                        int x=1;
                        p[z] = a[i][j];
                         printf("%d\n",p[z]);
                        t = check(i,j,b,x,z,len);
                        if(t == 1)
                            save(p[z],&n,b);
                        else if(t == 0){
                            printf("invalid point");
                            return;
                        }
                        j++;
                  //     printf("%d %d\n",p[0],p[1]);
                    }
                }
                else if((p[1]-p[0]) > 4){
                    for(z=0;z<len;z++){
                            int x=2;
                        p[z] = a[i][j];
                         t = check(i,j,b,x,z,len);
                        if(t == 1)
                            save(p[z],&n,b);
                        else if(t == 0){
                            printf("invalid point\n");
                            return;
                        }
                        i++;
              //        printf("%d %d\n",p[0],p[1]);
                    }
                }
                if(rim == 0)
                        addend(&head_1,p,len);
                if(rim == 1)
                        addend(&head_2,p,len);
               //  printf("%d",(head_1)->inf[0]);
                return;
            }
        }
    }
}

void save(int a, int *i, int b[100]){
    b[*i] = a;
    *i++;
}

int check(int i,int j, int b[100],int x,int m,int len){
    int k , v ,z;
    for(k=i-1;k<=i+1;k++){
        for(v=j-1;v<=j+1;v++){
            for(z=0;z<=100;z++){
                if(a[k][v] == b[z]){
                    if(x == 1){
                        if(m == 0){
                            if(a[k][v] == a[i][j+1])
                                continue;
                        }
                        else if(m == len-1){
                            if(a[k][v] == a[i][j-1])
                                continue;
                        }
                        else{
                            if(a[k][v] == a[i][j+1] || a[k][v] == a[i][j-1])
                                continue;
                        }
                    }
                    if(x == 2){
                        if(m == 0){
                            if(a[k][v] == a[i+1][j])
                                continue;
                        }
                        else if(m == len-1){
                            if(a[k][v] == a[i-1][j])
                                continue;
                        }
                        else{
                            if(a[k][v] == a[i+1][j] || a[k][v] == a[i-1][j])
                                continue;
                        }
                    }
                    return 0;
            }
        }
    }
    return 1;
}
}


