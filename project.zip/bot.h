#include <stdio.h>

typedef struct{
    int inf[5];
    struct nod *next;
}nod;

int a[20][20];

nod *head_1;
nod *head_2;

void bot(){
    int i , p[20] , j , k=1 , l=2;
    for(i=0;i<4;i++){
       p[0] = a[k][l];
       addend(&head_2,p,1);
       l++;
       k += 2;
    }
    p[0] = a[3][1];
    p[1] = a[4][1];
    addend(&head_2,p,2);
    p[0] = a[4][1];
    p[1] = a[5][1];
    addend(&head_2,p,2);
    p[0] = a[3][5];
    p[1] = a[3][6];
    addend(&head_2,p,2);

    p[0] = a[1][8];
    p[1] = a[2][8];
    p[2] = a[3][8];
    addend(&head_2,p,3);
    p[0] = a[6][0];
    p[1] = a[6][1];
    p[2] = a[6][2];
    addend(&head_2,p,3);

    p[0] = a[8][0];
    p[1] = a[8][1];
    p[2] = a[8][2];
    p[3] = a[8][3];
    addend(&head_2,p,4);
   // printf(" goood\n");
}
