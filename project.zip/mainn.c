#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "choose.h"
//#include "ship.h"


int main()
{

    int i , n;
   n = printing();
    choose(n);
    return 0;
}

